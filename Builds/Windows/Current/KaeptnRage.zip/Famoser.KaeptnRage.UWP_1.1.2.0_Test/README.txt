zum installieren:

1. auf die .ps1 file rechtklicken und mit powershell ausf�hren
2. profit