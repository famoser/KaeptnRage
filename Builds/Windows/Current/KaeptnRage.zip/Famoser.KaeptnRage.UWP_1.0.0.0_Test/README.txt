To install:
Execute Add-AppDevPackage.ps1 with Admin rights

have fun